﻿
namespace Eloqua.Models.Content
{
    public class RawHtmlContent : HtmlContent
    {
        public string Html { get; set; }
    }
}
