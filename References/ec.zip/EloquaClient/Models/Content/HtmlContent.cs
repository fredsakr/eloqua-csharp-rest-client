﻿
namespace Eloqua.Models.Content
{
    public abstract class HtmlContent
    {
    }
}
